//
//  main.m
//  YZCollectionViewDemo
//
//  Created by 韩云智 on 16/10/25.
//  Copyright © 2016年 韩云智. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
