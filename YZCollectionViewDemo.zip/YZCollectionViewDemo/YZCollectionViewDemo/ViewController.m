//
//  ViewController.m
//  YZCollectionViewDemo
//
//  Created by 韩云智 on 16/10/25.
//  Copyright © 2016年 韩云智. All rights reserved.
//

#import "ViewController.h"
#import "YZCollectionVC.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton * btn = [UIButton buttonWithType:UIButtonTypeContactAdd];
    [btn addTarget:self action:@selector(onBtn:) forControlEvents:UIControlEventTouchUpInside];
    btn.center = self.view.center;
    [self.view addSubview:btn];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.view.userInteractionEnabled = YES;
}

- (void)onBtn:(UIButton *)sender{
    self.view.userInteractionEnabled = NO;
    YZCollectionVC * vc = [YZCollectionVC new];
    UINavigationController * nvc = [[UINavigationController alloc]initWithRootViewController:vc];
    [self presentViewController:nvc animated:YES completion:^{
        
    }];
}


@end
