//
//  YZCollectionVC.h
//  YZCollectionViewDemo
//
//  Created by 韩云智 on 16/10/25.
//  Copyright © 2016年 韩云智. All rights reserved.
//

#import "ViewController.h"

@interface YZCollectionVC : UIViewController

@end
