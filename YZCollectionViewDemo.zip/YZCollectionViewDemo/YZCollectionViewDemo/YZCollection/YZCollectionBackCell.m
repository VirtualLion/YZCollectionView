//
//  YZCollectionBackCell.m
//  YZCollectionViewDemo
//
//  Created by 韩云智 on 16/10/25.
//  Copyright © 2016年 韩云智. All rights reserved.
//

#import "YZCollectionBackCell.h"

@implementation YZCollectionBackCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self upView];
    }
    return self;
}
- (void)upView{
    self.backgroundColor = [UIColor clearColor];
    self.layer.borderColor = [[UIColor redColor] CGColor];
}
@end
