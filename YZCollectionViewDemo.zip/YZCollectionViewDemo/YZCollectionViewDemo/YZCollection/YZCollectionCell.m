//
//  YZCollectionCell.m
//  YZCollectionViewDemo
//
//  Created by 韩云智 on 16/10/25.
//  Copyright © 2016年 韩云智. All rights reserved.
//

#import "YZCollectionCell.h"

@implementation YZCollectionCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self upView:self.bounds];
    }
    return self;
}
- (void)upView:(CGRect)frame{
    _myLabel = [UILabel new];
    _myLabel.frame = frame;
    _myLabel.textAlignment = NSTextAlignmentCenter;
    [self.contentView addSubview:_myLabel];
}

@end
