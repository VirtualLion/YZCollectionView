//
//  YZCollectionVC.m
//  YZCollectionViewDemo
//
//  Created by 韩云智 on 16/10/25.
//  Copyright © 2016年 韩云智. All rights reserved.
//

#import "YZCollectionVC.h"

#import "YZCollectionBackCell.h"
#import "YZCollectionCell.h"

@interface YZCollectionVC ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@property (nonatomic, strong) UICollectionView * myCollectionView;
@property (nonatomic, strong) UICollectionView * backCollectionView;

@property (nonatomic, strong) NSMutableArray * allData;
@property (nonatomic, strong) NSMutableArray * myData;
@property (nonatomic, strong) NSMutableArray * lastData;

@property (nonatomic, assign) BOOL isInsert;

//编辑
//@property (nonatomic, strong) UILongPressGestureRecognizer * longPress;
@property (nonatomic, strong) UIPanGestureRecognizer * longPress;

@property (nonatomic, assign) BOOL isEdit;

@end

@implementation YZCollectionVC

#pragma mark --- 事件【S】
- (void)onRight:(UIButton *)sender{
    sender.selected = !sender.selected;
    if (sender.selected) {
        _isEdit = YES;
        [_myCollectionView addGestureRecognizer:_longPress];
    }else{
        _isEdit = NO;
        [_myCollectionView removeGestureRecognizer:_longPress];
    }
    [_myCollectionView reloadData];
    [_backCollectionView reloadData];
}

- (void)lonePressMoving:(UIPanGestureRecognizer *)longPress
{
    
    switch (longPress.state) {
        case UIGestureRecognizerStateBegan: {
            {
                NSIndexPath *selectIndexPath = [_myCollectionView indexPathForItemAtPoint:[longPress locationInView:_myCollectionView]];
                if (selectIndexPath.section == 0) {
                    [_myCollectionView beginInteractiveMovementForItemAtIndexPath:selectIndexPath];
                }
            }
            break;
        }
        case UIGestureRecognizerStateChanged: {
            [_myCollectionView updateInteractiveMovementTargetPosition:[longPress locationInView:longPress.view]];
            break;
        }
        case UIGestureRecognizerStateEnded: {
            [_myCollectionView endInteractiveMovement];
            break;
        }
        default: [_myCollectionView cancelInteractiveMovement];
            break;
    }
}
#pragma mark --- 事件【E】
- (void)viewDidLoad {
    [super viewDidLoad];

    [self myNav];
    [self getData];
    [self myView];
}

- (void)myNav{
    self.edgesForExtendedLayout =UIRectEdgeNone;
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
    UIButton *rBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    rBtn.frame = CGRectMake(0, 0, 38, 38);
    [rBtn setTitle:@"编辑" forState:UIControlStateNormal];
    [rBtn setTitle:@"完成" forState:UIControlStateSelected];
    [rBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [rBtn addTarget: self action: @selector(onRight:) forControlEvents: UIControlEventTouchUpInside];
    UIBarButtonItem * rItem=[[UIBarButtonItem alloc]initWithCustomView:rBtn];
    self.navigationItem.rightBarButtonItem=rItem;
}

- (void)getData{
    _allData = [NSMutableArray new];
    _myData = [NSMutableArray new];
    
    for (NSInteger i = 0; i<30; i++) {
        [_allData addObject:@(i)];
    }
    
    [_myData addObjectsFromArray:[[NSUserDefaults standardUserDefaults]objectForKey:@"data"]];
    _lastData = [NSMutableArray arrayWithArray:_allData];
    [_lastData removeObjectsInArray:_myData];
}

- (void)myView{
    self.view.backgroundColor = [UIColor whiteColor];
    _isInsert = NO;
    _isEdit = NO;
    
    _backCollectionView = [self myCollectionView:[YZCollectionBackCell class]];
    _backCollectionView.userInteractionEnabled = NO;
    
    _myCollectionView = [self myCollectionView:[YZCollectionCell class]];
    [self.view bringSubviewToFront:_myCollectionView];
    
    UIPanGestureRecognizer * longPress = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(lonePressMoving:)];
    _longPress = longPress;
}

- (UICollectionView *)myCollectionView:(Class)cellClass
{
    UICollectionViewFlowLayout * flowLayout = [UICollectionViewFlowLayout new];
    flowLayout.minimumLineSpacing = 20;
    flowLayout.minimumInteritemSpacing = 20;
    flowLayout.itemSize = CGSizeMake(50, 20);
    flowLayout.sectionInset = UIEdgeInsetsMake(20, 20, 20, 20);
    
    UICollectionView * collectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:flowLayout];
    collectionView.backgroundColor = [UIColor clearColor];
    collectionView.dataSource = self;
    collectionView.delegate = self;
    
    [collectionView registerClass:cellClass forCellWithReuseIdentifier:@"myCell"];
    
    [self.view addSubview:collectionView];
    return collectionView;
}

#pragma mark --- CollectionView【S】

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    if (_isEdit) {
        return 1;
    }else{
        return 2;
    }
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    if (section==0) {
        if (_isInsert) {
            return _myData.count+1;
        }else{
            return _myData.count;
        }
    }else{
        return _lastData.count;
    }
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    if (collectionView == _backCollectionView) {
        YZCollectionBackCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"myCell" forIndexPath:indexPath];
        if (indexPath.section == 0) {
            if (indexPath.item >= _myData.count) {
                cell.layer.borderWidth = 0;
            }else{
                cell.layer.borderWidth = 1;
            }
        }
        return cell;
    }else{
        YZCollectionCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"myCell" forIndexPath:indexPath];
        if (indexPath.section == 0) {
            if (indexPath.item >= _myData.count) {
                cell.backgroundColor = [UIColor clearColor];
                cell.myLabel.text = @"";
            }else{
                cell.backgroundColor = [UIColor greenColor];
                cell.myLabel.text = [NSString stringWithFormat:@"%@",_myData[indexPath.item]];
                cell.myLabel.textColor = [UIColor blackColor];
            }
        }else{
            cell.myLabel.text = [NSString stringWithFormat:@"%@",_lastData[indexPath.item]];
            cell.myLabel.textColor = [UIColor whiteColor];
            cell.backgroundColor = [UIColor blueColor];
        }
        return cell;
    }
    return nil;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    if (_isEdit) {
        return;
    }
    collectionView.userInteractionEnabled = NO;
    if (indexPath.section == 0) {
        [_lastData insertObject:_myData[indexPath.item] atIndex:0];
        [_myData removeObjectAtIndex:indexPath.item];
        [[NSUserDefaults standardUserDefaults] setObject:_myData forKey:@"data"];
        [_myCollectionView reloadData];
        [_backCollectionView reloadData];
        collectionView.userInteractionEnabled = YES;
    }else{
        _isInsert = YES;
        NSIndexPath * indexPath2 = [NSIndexPath indexPathForItem:_myData.count inSection:0];
        
        [collectionView performBatchUpdates:^{
            [collectionView insertItemsAtIndexPaths:@[indexPath2]];
            [_backCollectionView insertItemsAtIndexPaths:@[indexPath2]];
        } completion:^(BOOL finished) {
            if (finished) {
                UICollectionViewCell * cell1 = [collectionView cellForItemAtIndexPath:indexPath];
                UICollectionViewCell * cell2 = [collectionView cellForItemAtIndexPath:indexPath2];
                
                [UIView animateWithDuration:0.25 animations:^{
                    cell1.frame = cell2.frame;
                } completion:^(BOOL finished) {
                    if (finished) {
                        [_myData insertObject:_lastData[indexPath.item] atIndex:_myData.count];
                        [_lastData removeObjectAtIndex:indexPath.item];
                        _isInsert = NO;
                        [_myCollectionView reloadData];
                        [_backCollectionView reloadData];
                        [[NSUserDefaults standardUserDefaults] setObject:_myData forKey:@"data"];
                        collectionView.userInteractionEnabled = YES;
                    }
                }];
                
            }
        }];
        
    }
}
- (void)collectionView:(UICollectionView *)collectionView moveItemAtIndexPath:(nonnull NSIndexPath *)sourceIndexPath toIndexPath:(nonnull NSIndexPath *)destinationIndexPath{
    
//    [_myData exchangeObjectAtIndex:sourceIndexPath.item withObjectAtIndex:destinationIndexPath.item];
    
    id object = _myData[sourceIndexPath.item];
    [_myData removeObject:object];
    [_myData insertObject:object atIndex:destinationIndexPath.item];
    
    [_myCollectionView reloadData];
    [[NSUserDefaults standardUserDefaults] setObject:_myData forKey:@"data"];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    _backCollectionView.contentOffset = _myCollectionView.contentOffset;
}
#pragma mark --- CollectionView【E】
@end
