//
//  YZCollectionCell.h
//  YZCollectionViewDemo
//
//  Created by 韩云智 on 16/10/25.
//  Copyright © 2016年 韩云智. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YZCollectionCell : UICollectionViewCell

@property (nonatomic, strong) UILabel * myLabel;

@end
